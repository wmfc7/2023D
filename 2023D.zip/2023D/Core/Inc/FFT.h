#ifndef __FFT_H
#define __FFT_H

#define FFT_LENGTH 4096
#define Pi 3.14159265359

void FFT_Analysis(void);
void Z_transform(void);
#endif

