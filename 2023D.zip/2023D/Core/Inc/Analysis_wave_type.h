#ifndef __Analysis_wave_type_H
#define __Analysis_wave_type_H

#include "main.h"

#define AM 1
#define FM 2
#define CW 3
#define ASK1 4
#define PSK1 5
#define FSK1 6
#define NONE 0

void Analysis_wave_type(void);
void jietiao(void);
int FindPeaksNumber(float arr[], int n);
int max(int a,int b);
int min(int a,int b);

#endif
