#ifndef _ADF4351_H_
#define _ADF4351_H_

#include "main.h"
//#define ADF4351_CE(a) HAL_GPIO_WritePin(GPIOD,GPIO_PIN_14,a)
//#define ADF4351_LE(a) HAL_GPIO_WritePin(GPIOG,GPIO_PIN_2,a)
//#define ADF4351_OUTPUT_DATA(a) HAL_GPIO_WritePin(GPIOG,GPIO_PIN_4,a)
//#define ADF4351_CLK(a)		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_6,a)

#define ADF4351_CE(a) 				HAL_GPIO_WritePin(GPIOD,GPIO_PIN_12,a)
#define ADF4351_LE(a) 				HAL_GPIO_WritePin(GPIOG,GPIO_PIN_2,a)
#define ADF4351_OUTPUT_DATA(a) 		HAL_GPIO_WritePin(GPIOG,GPIO_PIN_4,a)
#define ADF4351_CLK(a)				HAL_GPIO_WritePin(GPIOG,GPIO_PIN_6,a)

#define SET GPIO_PIN_SET
#define RESET GPIO_PIN_RESET
//										���õĹܽ�
#define ADF4351_INPUT_DATA HAL_GPIO_ReadPin(GPIOF,GPIO_PIN_0)

#define ADF4351_RF_OFF	((uint32_t)0XEC801C)

void ADF4351Init(void);
void ReadToADF4351(uint8_t count, uint8_t *buf);
void WriteToADF4351(uint8_t count, uint8_t *buf);
void WriteOneRegToADF4351(uint32_t Regster);
void ADF4351_Init_some(void);
void ADF4351WriteFreq(float Fre);		//	(xx.x) M Hz

extern float ZaiboFre;
void ADF4351WriteFreq_JietiaoFM(float Fre,float fffr);
void JietiaoFM(float ZF);
void SetFre(float FRE);

#endif

