#ifndef __MENU_H
#define __MENU_H

#include "main.h"

void MENU_Init(void);
void MENU_result_display(void);

#endif 
