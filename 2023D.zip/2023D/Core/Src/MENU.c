#include "lcd.h"
#include "MENU.h"
#include "Analysis_wave_type.h"
#include "AD9959.h"

__IO float m_a;
__IO float F;
__IO float m_f;
__IO float delta_f;
__IO float R_c;
__IO float h;
__IO uint8_t Wave_type;


void MENU_Init(void)
{
	AD9959_Init();
	AD9959_Set_Fre(CH0, 2100000);
	AD9959_Set_Amp(CH0, 1023);
	AD9959_Set_Phase(CH0, 0);
	IO_Update();
	
  lcd_init(); //lcd初始化
  lcd_display_dir(1);  //设置lcd为横屏
  lcd_clear(WHITE);   //设置lcd背景为白色
	g_point_color = BLACK;
  lcd_show_string(120, 100, 100, 50, 24, "2023D", g_point_color);
	HAL_Delay(500);
	lcd_clear(WHITE);
	
}

void MENU_result_display(void)
{
	switch(Wave_type)
	{
		case CW:
			lcd_display_dir(0);
			lcd_show_string(70, 40, 100, 50, 24, "Wave_type", g_point_color);
			lcd_show_string(110, 80, 100, 50, 24, "CW", g_point_color);
			break;
		
		case AM:
			lcd_display_dir(1);
			lcd_draw_line(160, 0, 160, 240, g_point_color);
			lcd_display_dir(0);
			lcd_show_string(70, 40, 100, 50, 24, "Wave_type", g_point_color);
			lcd_show_string(110, 80, 100, 50, 24, "AM", g_point_color);
			lcd_show_string(40, 180, 100, 50, 24, "F=               ", g_point_color);
			lcd_show_string(40, 210, 100, 50, 24, "m_a=             ", g_point_color);
			LCD_ShowFloat(60, 180, 16, F, 2, 2);
			LCD_ShowFloat(90, 210, 16, m_a, 2, 2);
			lcd_show_string(110, 180, 100, 50 , 24, "kHz", g_point_color);
		break;
		
		case FM:
			lcd_display_dir(1);
			lcd_draw_line(160, 0, 160, 240, g_point_color);
			lcd_display_dir(0);
			lcd_show_string(70, 40, 100, 50, 24, "Wave_type", g_point_color);
			lcd_show_string(110, 80, 100, 50, 24, "FM", g_point_color);
			lcd_show_string(40, 180, 100, 50, 24, "F=         ", g_point_color);
			lcd_show_string(40, 210, 100, 50, 24, "m_f=         ", g_point_color);
			lcd_show_string(40, 240, 100, 50, 24, "f_max=         ", g_point_color);
			LCD_ShowFloat(60, 180, 16, F, 2, 2);
			LCD_ShowFloat(90, 210, 16, m_f, 2, 2);
			LCD_ShowFloat(120, 240, 16, delta_f, 2, 2);
			lcd_show_string(110, 180, 100, 50 , 24, "kHz", g_point_color);
  		lcd_show_string(160, 240, 100, 50 , 24, "kHz", g_point_color);
		break;
		
		case ASK1:
			lcd_display_dir(1);
			lcd_draw_line(160, 0, 160, 240, g_point_color);
			lcd_display_dir(0);
			lcd_show_string(70, 40, 100, 50, 24, "Wave_type", g_point_color);
			lcd_show_string(100, 80, 100, 50, 24, "2ASK", g_point_color);
			lcd_show_string(40, 180, 100, 50, 24, "R_c=         ", g_point_color);
			LCD_ShowFloat(80, 180, 16, R_c, 2, 2);
		  lcd_show_string(130, 180, 100, 50, 24, "kbps", g_point_color);
		break;
			
		case FSK1:
			lcd_display_dir(1);
			lcd_draw_line(160, 0, 160, 240, g_point_color);
			lcd_display_dir(0);
			lcd_show_string(70, 40, 100, 50, 24, "Wave_type", g_point_color);
			lcd_show_string(100, 80, 100, 50, 24, "2FSK", g_point_color);
			lcd_show_string(40, 180, 100, 50, 24, "R_c=         ", g_point_color);
			lcd_show_string(40, 220, 100, 50, 24, "h=         ", g_point_color);
			LCD_ShowFloat(80, 180, 16, R_c, 2, 2);
			LCD_ShowFloat(60, 210, 16, h, 2, 2); 
		  lcd_show_string(130, 180, 100, 50, 24, "kbps", g_point_color);
		break;
		
		case PSK1:
			lcd_display_dir(1);
			lcd_draw_line(160, 0, 160, 240, g_point_color);
			lcd_display_dir(0);
			lcd_show_string(70, 40, 100, 50, 24, "Wave_type", g_point_color);
			lcd_show_string(100, 80, 100, 50, 24, "2PSK", g_point_color);
			lcd_show_string(40, 180, 100, 50, 24, "R_c=         ", g_point_color);
			LCD_ShowFloat(90, 180, 16, R_c, 2, 2);
		  lcd_show_string(140, 180, 100, 50, 24, "kbps", g_point_color);
		break;
		
	}
}

