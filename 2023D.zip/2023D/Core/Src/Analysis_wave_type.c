#include "stdlib.h"
#include "math.h"
#include "gpio.h"
#include "ADF4002.h"
#include "ADF4351.h"
#include "AD9959.h"
#include "Analysis_wave_type.h"
#include "FFT.h"

extern float m_a;
extern float F;
extern float m_f;
extern float delta_f;
extern float R_c;
extern float h;
extern uint8_t Wave_type;

int nbrOfpeak;
float max_amp_0;
float max_amp_1;
int max_freq_0;
int max_freq_1;
int max_0;
int max_1;
uint8_t sure0;
uint8_t sure1;
uint8_t sure2;
float min_amp;
int nbrOfMainPeak;
float mean_delta_freq;

__IO float Amp_Result[FFT_LENGTH/2];

void Analysis_wave_type(void)
{	
		Wave_type = NONE;
    nbrOfpeak = FindPeaksNumber(Amp_Result, FFT_LENGTH/2);
    
    float PeakAmp[nbrOfpeak];
		int PeakFreq[nbrOfpeak];
		float delta_freq[nbrOfpeak - 1];

    int count = 0;
    if((Amp_Result[0]>Amp_Result[1])&&(Amp_Result[0] > 30.0f))
    {
        PeakAmp[count] = Amp_Result[0];
        PeakFreq[count] = 0;
        count++;
    }
    for(int i = 1; i < FFT_LENGTH/2 - 1; i++)
    {
        if((Amp_Result[i] > Amp_Result[i-1])&&(Amp_Result[i]>Amp_Result[i+1])&&(Amp_Result[i]>30.0f))
        {
            PeakFreq[count] = i;
            PeakAmp[count] = Amp_Result[i];
            count++;
        }
    }
    
    if((Amp_Result[FFT_LENGTH/2-1]>30.0f)&&(Amp_Result[FFT_LENGTH/2-1]>Amp_Result[FFT_LENGTH/2-2]))
    {
        PeakAmp[count] = Amp_Result[FFT_LENGTH/2 - 1];
        PeakFreq[count] = FFT_LENGTH/2 - 1;
    }
    for(int i=0;i<nbrOfpeak;i++)
    {
        if(i==0)
        {
            min_amp = 1000.0;
        }
        min_amp = fminf(min_amp,PeakAmp[i]);
    }
    nbrOfMainPeak = min(3,FindPeaksNumber(PeakAmp,nbrOfpeak));
    count = 0;
    float MainPeakAmp[nbrOfMainPeak];
    int MainPeakFreq[nbrOfMainPeak];
    if((PeakAmp[0]>PeakAmp[1])&&(PeakAmp[0]-min_amp)>55.0f)
    {
        MainPeakAmp[count] = PeakAmp[0];
        MainPeakFreq[count] = PeakFreq[0];
        count++;
    }
    for(int i = 1; i < nbrOfpeak - 1; i++)
    {
        if((PeakAmp[i] > PeakAmp[i-1])&&(PeakAmp[i]>PeakAmp[i+1])&&(PeakAmp[i]-min_amp)>55.0f)
        {
            MainPeakAmp[count] = PeakAmp[i];
            MainPeakFreq[count] = PeakFreq[i];
            count++;
        }
    }
    
    if((PeakAmp[nbrOfpeak-1]>PeakAmp[nbrOfpeak-2]) &&(PeakAmp[nbrOfpeak-1]-min_amp)>55.0f)
    {
        MainPeakAmp[count] = PeakAmp[nbrOfpeak - 1];
        MainPeakFreq[count] = PeakFreq[nbrOfpeak - 1];
        count++;
    }
    nbrOfMainPeak = count;
    for(int i = 0; i < nbrOfpeak; i++)
    {
        if (PeakAmp[i] > max_amp_0) 
        {
            max_amp_1 = max_amp_0;
            max_freq_1 = max_freq_0;
            max_1 = max_0;
            max_amp_0 = PeakAmp[i];
            max_freq_0 = PeakFreq[i];
            max_0= i;
        } 
        else if (PeakAmp[i] < max_amp_0 && PeakAmp[i] > max_amp_1)
        {
            max_amp_1 = PeakAmp[i];
            max_freq_1 = PeakFreq[i];
            max_1 = i;
        }

    }

    
    
    sure0 = 0;
    if(abs(max_0-max_1)==2 && PeakAmp[max(max_0,max_1)-1]/max_amp_0 <= 0.2f)
    {
        sure0 = 1;  //�ж�˫���Ƿ�����
    }
    if(abs(max_0-max_1)==1 && (max_amp_0-max_amp_1)/max_amp_0 <= 0.2f)
    {
        sure0 = 1;
    }
    for (int i = nbrOfpeak-1; i>0; i--)
    {
        delta_freq[nbrOfpeak - 1 - i] = PeakFreq[i] - PeakFreq[i-1];
    }
		sure2 = 0;
    if(nbrOfMainPeak == 1)   //�ж��Ƿ��ǵ�����
    {
        sure2 = 1;
        if(sure0 == 1)
        {
            sure2 = 0;
        }
    }
    else if(nbrOfMainPeak>1)
    {
        sure2 = 0;
    }
    
    for(int i = 1;i<nbrOfpeak-1;i++)  //�ж����ڷ��Ƶ��֮���Ƿ����
    {
			if(i == 1)	
			{
				sure1 = 1;
			}
			if(fabs(delta_freq[i] - delta_freq[i-1]) >= 2.0f)
			{
				sure1 = 0;
                
				if(delta_freq[i]/2-delta_freq[i-1]<=1.5f && sure2 == 0)
				{
					sure1 = 1;
					delta_freq[i] /= 2;
				}
                
			}
    }
		
		for(int i = 0; i<nbrOfpeak-1;i++)
		{
			if(i==0)
			{
				mean_delta_freq = 0;
			}
			mean_delta_freq += delta_freq[i];
		}
		mean_delta_freq /= nbrOfpeak-1;
    
    if(nbrOfpeak == 1)
    {
        Wave_type = CW;
    }
    if(nbrOfpeak == 3)
    {
				Wave_type = AM;
				F = (float)(PeakFreq[2] - PeakFreq[0])/2/FFT_LENGTH*400;
				m_a = (PeakAmp[1] - min(PeakAmp[0],PeakAmp[2]))/(PeakAmp[1] + min(PeakAmp[0],PeakAmp[2]));
				jietiao();
    }
    if(nbrOfpeak > 3)
    {
        if((max_amp_0 - max_amp_1)/max_amp_0 <= 0.2f && abs(max_freq_0 + max_freq_1 - FFT_LENGTH/2) <= 1 && sure0 == 1)
        {
            Wave_type = PSK1;
						R_c = (float)abs(max_freq_1 - max_freq_0)/2/FFT_LENGTH*400;
						jietiao();
        }
        else
        {
            if(abs(max_freq_0 - FFT_LENGTH/4) <= 1 && abs(PeakFreq[max_0-1]+PeakFreq[max_0+1]-FFT_LENGTH/2)<=1 && sure1 == 0 && sure2 == 1)
            {
                Wave_type = ASK1;
								R_c = (float)(PeakFreq[max_0+1]-PeakFreq[max_0-1])/2/FFT_LENGTH*400;
								jietiao();
            }
            else if(sure1 == 1 && sure0 == 0 && sure2 == 0 && mean_delta_freq > 55.0f)
            {
                Wave_type = FSK1;
							  R_c = mean_delta_freq/FFT_LENGTH*400;
								h = abs(MainPeakFreq[0] - MainPeakFreq[nbrOfMainPeak-1])/mean_delta_freq/2;
								jietiao();
            }
            else
            {
                Wave_type = FM;
								F = mean_delta_freq/FFT_LENGTH*400;
								m_f = (float)(PeakFreq[nbrOfpeak-1]-PeakFreq[0])/2/F/FFT_LENGTH*400-1;
								delta_f = F*m_f;
								jietiao();
            }
        }
    }

}

void jietiao(void)
{
    switch (Wave_type)
    {
    case AM:
        AD9959_Init();
        AD9959_Set_Fre(CH0,8700000);
        AD9959_Set_Amp(CH0,1023);
        AD9959_Set_Phase(CH0,0);
        IO_Update();
        HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOB,GPIO_PIN_8,GPIO_PIN_SET);
		
        break;
    case FM:
        AD9959_Init();
        AD9959_Set_Fre(CH0,8700000);
        AD9959_Set_Amp(CH0,1023);
        AD9959_Set_Phase(CH0,0);
        IO_Update();
        ADF4351Init();
        ADF4351WriteFreq_JietiaoFM(48,10.7);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_6,GPIO_PIN_SET);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_9,GPIO_PIN_SET);

        break;
    case ASK1:
        AD9959_Init();
        AD9959_Set_Fre(CH0,8700000);
        AD9959_Set_Amp(CH0,1023);
        AD9959_Set_Phase(CH0,0);
        IO_Update();
		    HAL_GPIO_WritePin(GPIOB,GPIO_PIN_5,GPIO_PIN_SET);
				HAL_GPIO_WritePin(GPIOE,GPIO_PIN_0,GPIO_PIN_SET);

        break;
    case FSK1:
        AD9959_Init();
        AD9959_Set_Fre(CH0,8700000);
        AD9959_Set_Amp(CH0,1023);
        AD9959_Set_Phase(CH0,0);
        IO_Update();
				ADF4351Init();
        ADF4351WriteFreq_JietiaoFM(48,10.7);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_6,GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOE,GPIO_PIN_0,GPIO_PIN_SET);

        break;
    case PSK1:
        AD9959_Init();
        AD9959_Set_Fre(CH0,1900000);
        AD9959_Set_Amp(CH0,1023);
        AD9959_Set_Phase(CH0,0);
        IO_Update();
        InitADF4002();
        NDivideTest(2);
				HAL_GPIO_WritePin(GPIOB,GPIO_PIN_7,GPIO_PIN_SET);
        HAL_GPIO_WritePin(GPIOE,GPIO_PIN_0,GPIO_PIN_SET);

        break;
    default:
        return;

    }
}

int FindPeaksNumber(float arr[], int n)
{
    int count = 0;
    if((arr[0]>arr[1])&&(arr[0] > 30.0f))
        count++;

    for(int i = 1; i < n - 1; i++)
    {
        if((arr[i] > arr[i-1])&&(arr[i]>arr[i+1])&&(arr[i]>30.0f))
            count++;
    }

    if((arr[n-1]>30.0f)&&(arr[n-1]>arr[n-2]))
        count++;
        
    return count; 
}


int max(int a,int b)
{
    if(a>b)
    {
        return a;
    }
    else
    {
        return b;
    }
}

int min(int a,int b)
{
    if(a<b)
    {
        return a;
    }
    else
    {
        return b;
    }
}
