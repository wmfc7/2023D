#include "adc.h"
#include "dma.h"
#include "tim.h"
#include "AD9959.h"
#include "stdio.h"
#include "stm32h7xx_it.h"
#include "arm_math.h"
#include "arm_math_types.h"
#include "arm_common_tables.h"
#include "arm_const_structs.h"
#include "FFT.h"
#include "math.h"

extern float Amp_Result[FFT_LENGTH/2];

uint16_t ADC2_Value[FFT_LENGTH];
float FFT_Input[FFT_LENGTH*2] = {0};
float FFT_Output[FFT_LENGTH*2] = {0};
float FFT_Re;
float FFT_Im;

__IO uint8_t DMA_CONVERSION = 0;

void FFT_Analysis(void)
{
	HAL_TIM_Base_Start(&htim2);
	HAL_ADC_Start_DMA(&hadc2, (uint32_t *)ADC2_Value,FFT_LENGTH);
	
	while(DMA_CONVERSION!=2);
	
	HAL_TIM_Base_Stop(&htim2);
	HAL_ADC_Stop_DMA(&hadc2);
	DMA_CONVERSION = 0;

	for (uint16_t i = 0; i < FFT_LENGTH; i++)
    {  
		FFT_Input[i * 2] = ADC2_Value[i];  
		FFT_Input[i * 2 + 1] = 0;  
	}  
		
	arm_cfft_f32(&arm_cfft_sR_f32_len4096, FFT_Input, 0, 1);  
	arm_cmplx_mag_f32(FFT_Input, FFT_Output, FFT_LENGTH);  
  
	FFT_Output[0] /= FFT_LENGTH;  
		
	for (uint16_t i = 0; i < FFT_LENGTH; i++)
	{  
		FFT_Output[i] /= FFT_LENGTH / 2;
	}

	for(int i = 0; i < FFT_LENGTH/2; i++)
  {
    Amp_Result[i] = FFT_Output[i]/4096*3300;
  }
	
}